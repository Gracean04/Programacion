package sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;


public class Play
{
 @FXML
    Button A1;
 @FXML
    Button A2;
 @FXML
    Button A3;
 @FXML
    Button B1;
 @FXML
    Button B2;
 @FXML
    Button B3;
 @FXML
    Button C1;
 @FXML
    Button C2;
 @FXML
    Button C3;

     public void A1 (ActionEvent event) {
        if (A1.getText().toString().equals("")) {
             A1.setText("X");
             if (!A3.getText().equals(""))
                 A2.setText("0");
             else if (!C3.getText().equals(""))
                 B2.setText("0");
             else if (!C1.getText().equals(""))
                 B1.setText("0");
             else
                 A3.setText("0");
         }

     }


    public void B2(ActionEvent event) {
        if (B2.getText().toString().equals("")) {
            B2.setText("X");
            if (!A3.getText().equals(""))
                C1.setText("0");
            else if (!C3.getText().equals(""))
                A1.setText("0");
            else if (!C1.getText().equals(""))
                A3.setText("0");
            else if (!A1.getText().equals(""))
                C3.setText("0");
            else C3.setText("0");
        }
    }

    public void A2 (ActionEvent event) {
        if (A2.getText().toString().equals("")) {
            A2.setText("X");
            if (!C3.getText().equals(""))
                B1.setText("0");
            else if (!C3.getText().equals(""))
                C1.setText("0");
            else if (!B2.getText().equals(""))
                C2.setText("0");
            else
                C2.setText("0");
        }
    }

    

    public void B1(ActionEvent event) {

    }

    public void C3(ActionEvent event) {
    }

    public void C2(ActionEvent event) {
    }

    public void C1(ActionEvent event) {
    }

    public void B3(ActionEvent event) {
    }

    public void A3(ActionEvent event) {
        A3.setText("X");
    }
}
